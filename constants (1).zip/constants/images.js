import Hoodie1 from './Hoodie_1.png';
import Hoodie2 from './Hoodie_2.png';
import open_wardrobe from './open_wardrobe.png';
import close_wardrobe from './close_wardrobe.png';
import tshirt_1 from './t-shirt_1.png';
import tshirt_2 from './t-shirt_2.png';
import tshirt_3 from './t-shirt_3.png';
import tshirt_4 from './t-shirt_4.png';
import tshirt_5 from './t-shirt_5.png';
import tshirt_6 from './t-shirt_6.png';
import puma_logo from './puma_logo.png';
import nike_logo from './nike_logo.png';
import Hoodie1_og from './Hoodie1_og.png';
import Hoodie1_ed from './Hoodie1_ed.png';
import Hoodie2_og from './Hoodie2_og.png';
import Hoodie3_og from './Hoodie3_og.png';
import Hoodie4_og from './Hoodie4_og.png';
import Hoodie2_ed from './Hoodie2_ed.png';
import Hoodie3_ed from './Hoodie3_ed.png';
import Hoodie4_ed from './Hoodie4_ed.png';
import Shirt1_og from './Shirt1_og.png';
import Shirt2_og from './Shirt2_og.png';
import Shirt1_ed from './Shirt1_ed.png'
import Shirt2_ed from './Shirt2_ed.png';
import Pants1_og from './Pants1_og.png';
import Pants2_og from './Pants2_og.png';
import Pants3_og from './Pants3_og.png';
import Pants1_ed from './Pants1_ed.png';
import Pants2_ed from './Pants2_ed.png';
import Pants3_ed from './Pants3_ed.png';
import Tshirt2_og from './Tshirt2_og.png';
import Tshirt3_og from './Tshirt3_og.png';
import Tshirt2_ed from './Tshirt2_ed.png';
import Tshirt3_ed from './Tshirt3_ed.png';
import levis_log from './levis_logo.png';
import adidas_logo from './adidas_logo.png';
import shirt_vector from './shirt_vector.png';
import trouser_vector from './trouser_vector.png';
import hoodie_vector from './hoodie_vector.png';
import tshirt_vector from './tshirt_vector.png'

export default{
    Hoodie1,
    Hoodie2,
    open_wardrobe,
    close_wardrobe,
    tshirt_1,
    tshirt_2,
    tshirt_3,
    tshirt_4,
    tshirt_5,
    tshirt_6,
    puma_logo,
    nike_logo,
    Hoodie1_og,
    Hoodie2_og,
    Hoodie3_og,
    Hoodie4_og,
    Hoodie1_ed,
    Hoodie2_ed,
    Hoodie3_ed,
    Hoodie4_ed,
    Shirt1_og,
    Shirt1_ed,
    Shirt2_ed,
    Shirt2_og,
    Tshirt2_ed,
    Tshirt2_og,
    Tshirt3_ed,
    Tshirt3_og,
    Pants1_ed,
    Pants1_og,
    Pants2_ed,
    Pants2_og,
    Pants3_ed,
    Pants3_og,
    levis_log,
    adidas_logo,
    shirt_vector,
    trouser_vector,
    hoodie_vector,
    tshirt_vector

}